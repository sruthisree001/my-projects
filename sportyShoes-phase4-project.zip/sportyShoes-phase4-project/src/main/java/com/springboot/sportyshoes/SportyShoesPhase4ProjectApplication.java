package com.springboot.sportyshoes;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportyShoesPhase4ProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportyShoesPhase4ProjectApplication.class, args);
	}

}
