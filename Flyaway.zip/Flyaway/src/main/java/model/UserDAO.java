package model;

public interface UserDAO {

	boolean signin(User user);
	boolean signup(User user);

}
