import { Complaint } from "./complaint";

export class Category{
	BroadBand:string;
	PrePaid:string;
	PostPaid:string;
	PlansDetails:string;
	complaint:Complaint;
}