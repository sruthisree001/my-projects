/**
 * 
 */
 
 document.addEventListener('DOMContentLoaded', function() {
    const balanceElement = document.querySelector('.account p');
    const withdrawBtn = document.getElementById('withdrawBtn');
    const depositBtn = document.getElementById('depositBtn');

    let balance = 1000;

    function updateBalance() {
        balanceElement.textContent = `Balance: $${balance}`;
    }

    updateBalance();

    withdrawBtn.addEventListener('click', function() {
        const amount = parseFloat(prompt('Enter withdrawal amount:'));
        if (!isNaN(amount) && amount > 0 && amount <= balance) {
            balance -= amount;
            updateBalance();
        } else {
            alert('Invalid amount or insufficient balance.');
        }
    });

    depositBtn.addEventListener('click', function() {
        const amount = parseFloat(prompt('Enter deposit amount:'));
        if (!isNaN(amount) && amount > 0) {
            balance += amount;
            updateBalance();
        } else {
            alert('Invalid amount.');
        }
    });
});