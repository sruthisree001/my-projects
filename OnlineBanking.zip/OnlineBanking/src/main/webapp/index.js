/**
 * 
 */
 const express = require('express');
const bodyParser = require('body-parser');
const mysql = require('mysql');

const app = express();
const port = 3000;

app.use(bodyParser.json());

const db = mysql.createConnection({
  host: 'localhost',
  user: 'your_username',
  password: 'your_password',
  database: 'your_database'
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL database');
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.query(
    'SELECT * FROM accounts WHERE username = ? AND password = ?',
    [username, password],
    (err, results) => {
      if (err) throw err;
      if (results.length > 0) {
        res.json({ success: true, message: 'Login successful' });
      } else {
        res.json({ success: false, message: 'Invalid credentials' });
      }
    }
  );
});

app.get('/balance/:account_number', (req, res) => {
  const accountNumber = req.params.account_number;
  db.query(
    'SELECT balance FROM accounts WHERE account_number = ?',
    [accountNumber],
    (err, results) => {
      if (err) throw err;
      if (results.length > 0) {
        res.json({ balance: results[0].balance });
      } else {
        res.json({ balance: 'Account not found' });
      }
    }
  );
});

app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});