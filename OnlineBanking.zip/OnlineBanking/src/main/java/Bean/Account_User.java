/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;

public class Account_User {
    public long Ac_No;
    public double Amount;
    public double Balance;
    public String Operate;
    public  String Tx_Date;
    public String Ref_No;

   
}
