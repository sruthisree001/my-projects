

package Bean;


public class RegisterUser {
   private String Salutation;
   private String Fname;
   private String DOB;
   private String Email_ID;
   private String Username;
   private long Mobile_no;
   private String Password;
   private String Country;

    /**
     * @return the Salutation
     */
    public String getSalutation() {
        return Salutation;
    }

    /**
     * @param Salutation the Salutation to set
     */
    public void setSalutation(String Salutation) {
        this.Salutation = Salutation;
    }

    /**
     * @return the Fname
     */
    public String getFname() {
        return Fname;
    }

    /**
     * @param Fname the Fname to set
     */
    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    /**
     * @return the DOB
     */
    public String getDOB() {
        return DOB;
    }

    /**
     * @param DOB the DOB to set
     */
    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    /**
     * @return the Email_ID
     */
    public String getEmail_ID() {
        return Email_ID;
    }

    /**
     * @param Email_ID the Email_ID to set
     */
    public void setEmail_ID(String Email_ID) {
        this.Email_ID = Email_ID;
    }

    /**
     * @return the Username
     */
    public String getUsername() {
        return Username;
    }

    /**
     * @param Username the Username to set
     */
    public void setUsername(String Username) {
        this.Username = Username;
    }

    /**
     * @return the Mobile_no
     */
    public long getMobile_no() {
        return Mobile_no;
    }

    /**
     * @param Mobile_no the Mobile_no to set
     */
    public void setMobile_no(long Mobile_no) {
        this.Mobile_no = Mobile_no;
    }

    /**
     * @return the Password
     */
    public String getPassword() {
        return Password;
    }

    /**
     * @param Password the Password to set
     */
    public void setPassword(String Password) {
        this.Password = Password;
    }

    /**
     * @return the Country
     */
    public String getCountry() {
        return Country;
    }

    /**
     * @param Country the Country to set
     */
    public void setCountry(String Country) {
        this.Country = Country;
    }
   
}
