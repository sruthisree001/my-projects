
//link to youtube
//https://www.youtube.com/watch?v=hdI2bqOjy3c



//console.log('Hello World');
// this ex to create var
let name='Mosh';
console.log(name);
//for constant variables
const interestRate= 0.3;
 //interestRate = 1; //we will get error here
                   //cant reassign a new value
 console.log(interestRate);

//for primitive types
let name2= 'mosh'; //string Literal
//let age=30; //Number 
let isApproved=false;  //Boolean
let firstName=undefined;  //undefined
let selectedColor=null;   //null

//reference datatypes
//a.Object
  let person={
     name3: 'mosh',
     age:30
};

//dot notation to read a property of object
person.name='john';

//Bracket Notation
let selection='name';  //this is for dynamic selection
person[selection]='Mary';

console.log(person);

//Arrays

let selectedColors=['red','Blue']; //Array declaration
console.log(selectedColors[0]);  //shows the first item
selectedColors[2] ='Green'; //to add item in the array


//Functions
    //this is function definition
    function greet() {
             console.log('hello world');
    }   
    //function declaration
    greet();
  //to pass the parameters to functionz]s
    function greet2(name) {
      console.log('hello '+name);
}   
//function declaration
greet('john'); //here john is an argment 
greet('Mary');
//performing a task
function greet2(name) {
  console.log('hello '+name +' '+ name2);

}
//function calculating a value
function square(Number){
  return Number*Number;
}
let number=square(2);

//or  we ca write as
console.log(square(2));
greet('h','s');


//creating Arrays and usage

const fruits2=['apples','oranges','pears'];
fruits2[3]='grapes'; //to add an item

fruits2.push('mango');// other way to push or add an item
fruits2.unshift('strawberries'); //to add elementsnin the starting
fruits2.pop(); //to remove an element
console.log(Array.isArray('hello'));// it is not in  array so it returns false
console.log(fruits2.indexOf('oranges'));// it returns the place of this in array


//to create an object

const person2 = {
  firstName: 'John',
  lastName: 'Doe',
  age: 30,
  hobbies:['music','movies','sports'],
  adrees: {street:'50 main street',
       city:'boston',
       state: 'MA'

}
}
//to get the values of person

console.log(person2.firstname,person.lastName);

//the new feature is
//we can pushout the elements from person

//const {firstNa,lastName,adreess: {city}} =person2;
//console.log(city);

//to add properties

person2.emil='John@gmail.com';
console.log(person2);

const todos=[
  {
    id:1,
    text:'Takeout trash',
    isCompleted: true

  },
  {
    id:2,
    text:'Meeting with boss',
    isCompleted: true
  },
  {
    id:3,
    text:'DEntist appt',
    isCompleted: false
  }
];
console.log(todos);

//for loop
for(let i=0;i<10;i++)
{
   console.log(i);
}
//while loop

let i=0;
while(i<10){
  console.log('while loop number:${i}');
  i++;
}

//for loop through arrays
for(let i=0;i<todos.length;i++){
   console.log(todos[i].text);
}
 
for(let todo of todos) {
  console.log(todo.id);
}

//forEach:which just loops through them
//map: which allow to create a array in loop
//filter:r=which allow to crate a array based on the condition
//these are high order array methods
todos.forEach(function(){
  console.log(todos.text);

});
//map 
const todoText=todos.map(function(todo){
  return todo.text;

});

//filter
const todoCompleted=todos.filter(function(todo)
{
  return todo.isCompleted ===true;
}).map(function(todo)
{
  return todo.text;
}
)
console.log(todoCompleted);

//conditionals
//IF
//  == only checks the value
// but === checks the datatypes
const x=10;
const y=101983;

if(x===10)   //bette to use ===
{
  console.log('x is 10');
} else if(x>10){
  console.log('x is greater than 10');
}

else{
   console.log('x is less than 10');
}
//or condition in if
if(x>5||y>10){
  console.log('x is more tan 5 or y is more than 10');
}
//ternaory operators to evaluate condition 
const x1=10;
//ternory operator 
//if x > 10 then color is red and otherwise it is blue
const color=x>10?'red':'blue';
console.log(color);

//switch
switch(color){
  case 'red':
     console.log('color is reed');
    break;
  case 'blue':
    console.log('color is Blue');
    break;
  default:
    console.log('color is NOT red or blue');
    break;
}

//functions
// we can create function using function keyword

function addNums(num1,num2){
  console.log(num1+num2);

}
addNums(); //we get NaN:: not a number
addNums(4,5); //we get 9 as a reuslt
//to return value

function addNums(num1,num2){
  return num1+num2;
}
console.log(addNums(3,6));

//Arrow Functions

const addNums2=(num1,num2) =>{
  return num1+num2;
}
console.log(addNums2(6,11));

//we can write above arrow function easily

const addNums3=(num1,num2) => num1+num2;
console.log(addNums3(8,10));

//this keyword :: look once

//object oriented program
   //constructorr function
function person3(firstName,lastName,dob){
  this.firstName=firstName;  //this is used to pass the values
  this.lastName=lastName;
  this.dob=new Date(dob); //it si used to save dated
                //console.log(persond2.dob.getFullYear());  //prints 1990
                //this can be writen as
              
              /*      this.getBirthYear=function(){
                          return this.dob.getFullYear();
                        }
                        this.getFullName=function(){
                          return `${this.firstName} ${this.lastName}`; //this gives the name completly
                                //these  dots are template literals before number 1 on keyboard 
                        }

                      
              */
              //but this is not the way to write it

              //we willget variables in the constructor..
              //but if we want functions also then we need to add them to prototype
              //the above code from 259 to 268 is also witen as

person3.prototype.getBirthYear = function() {
  return this.dob.getFullYear();
}

person3.prototype.getFullName =function() {
  return `${this.firstName} ${this.lastName}`;
}

}
//instantiate Object

const persond1=new person3('john','doe','4-3-1983');
const persond2=new person3('Mary','smith','3-6-1990');

console.log(persond1.firstName); //prints JOhn
console.log(persond1.getBirthYear());
//to get full name
console.log(persond1.getFullName());
//calling prototype function
console.log(persond2.getFullName());
console.log(persond1);


//we can do above instances as class

class person4 {
  constructor(firstName,lastName,dob)
  {
     this.firstName=firstName;
     this.lastName=lastName;
     this.dob=new Date(dob);

  }
  getBirthYear(){
    return this.dob.getFullYear();
  }
  getFullName(){
    return `${this.firstName} ${this.lastName}`;
  }
}

const persond3=new person4('john 2','doe','4-3-1984');
const persond4=new person4('Mary 2','smith','3-6-1994');

console.log(persond3);
console.log(persond4.getBirthYear());
console.log(persond4.getFullName());
console.log(persond3.getFullName());


console.log(window);//shows the list of object and functons,classes all related to the widow of the browser

//DOM

//how to selecting things from the dom

/*
we have 1.single element selectors
            
        2.mulltiple element selectors


*/

//single element selector

console.log(document.getElementById('my-form'));
console.log(document.querySelector('h1'));

//multiple element

console.log(document.querySelectorAll('.item'));
console.log(document.getElementsByClassName('item'));
console.log(document.getElementsByTagName('li'));

//loop through

const items=document.querySelectorAll('.items');
items.forEach((items) => console.log(items));

//how to take the element from the DOM and change the data

const ul=document.querySelector('.items');

//ul.remove(); -->remove the ul
//ul.lastElementChild.remove(); -->remove the last element
//ul.firstElementChild.textContent='Hello';

//ul.firstElementChild.textContent = 'sree'; //to change the first element in the list
//ul.children[1].innerText = 'sruthi'; // to change the middle element by number
//ul.lastElementChild.innerHTML='<h1>Hello</h1>';//to change the element from the last
                              //we can also write html in the selectors using "innerhtml"                              const btn=document.querySelector('.btn');
//btn.style.background='red';


//btn.addEventListener('click',(e)=>{
  //e.preventDefault(); //this prevent the default action of the button like flah on the console
  //console.log('click');
 // document.querySelector('#my-form').classList.add('bg-dark');
  
// console.log(e);
//});

//getElementById is better supported than 
//querySelector . querySelector is better supported 
//than getElementsByClassName but querySelector gives you a static node list 
//while getElementsByClassName gives you a live node list. 
//You need to pick the appropriate tool for any given task.

const btn=document.querySelector('btn');
/*btn.addEventListener('mouseout',(e)=>{
e.preventDefault();
document.querySelector('#my-form'),style.background='#ccc';
document.querySelector('body').classList.add('bg-dark');
document.querySelector('.items').lastElementChild.innerHTML='<h1>Hello</h1>';

});*/

 const myForm=document.querySelector('.form');
 const nameInput=document.querySelector('#name');
 const emailInput=document.querySelector('#email');
 const msg=document.querySelector('.msg');
 const userList=document.querySelector('#users');
/*if(myform){
   myform.addEventListener(myform.addEventListener('submit',onSubmit),
    function onSubmit(e)
    {
       e.preventDefault();
       console.log(nameInput.value);
    }
   );
}*/
 myForm.addEventListener('submit',onSubmit);

function onSubmit(e)
 {
    e.preventDefault();
    //console.log(nameInput.value);
    if(nameInput.value==='' || emailInput.value ==='') {
     // alert('please enter fields');
      msg.classList.add('error');
      msg.innerHTML='please enter the fields';

      setTimeout(()=>msg.remove(),3000);
    } else{
      //console.log('success');
      const li=document.createElement('li');
      li.appendChild(document.createTextNode(`${nameInput.value} : ${emailInput.value}`));
      userList.appendChild(li);
      //to clear the fields
      nameInput.value='';
      emailInput.value='';
    }
 }
